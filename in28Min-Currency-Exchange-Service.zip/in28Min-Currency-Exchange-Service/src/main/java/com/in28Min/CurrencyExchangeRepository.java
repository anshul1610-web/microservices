package com.in28Min;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CurrencyExchangeRepository extends JpaRepository<CurrencyExchange,Long>{
      CurrencyExchange findByFromAndTo(String From,String to);
}
