package com.in28Min;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class In28MinCurrencyExchangeServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(In28MinCurrencyExchangeServiceApplication.class, args);
		
		System.out.println("in Currency Exhange");
	}

}
