package com.in28Min;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class In28MinNamingServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
