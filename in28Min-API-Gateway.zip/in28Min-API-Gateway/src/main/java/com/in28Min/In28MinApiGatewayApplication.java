package com.in28Min;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class In28MinApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(In28MinApiGatewayApplication.class, args);
		System.out.println("in API Gateway");
	}

}
