package com.in28Min;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;

@EnableConfigServer
@SpringBootApplication
public class In28MinSpringCloudConfigServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(In28MinSpringCloudConfigServerApplication.class, args);
		System.out.println("in Spring Cloud Server Config");
	}

}
